class Word:
    def __init__(self, word, count):
        self.word = word
        self.count = count