package com.wikibooks.spark.ch5.scala

case class MyCls(id: String, value: Map[String, String])