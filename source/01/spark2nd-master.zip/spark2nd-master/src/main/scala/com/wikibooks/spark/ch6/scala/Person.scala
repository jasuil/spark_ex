package com.wikibooks.spark.ch6.scala

case class Person(name: String, age: Int)