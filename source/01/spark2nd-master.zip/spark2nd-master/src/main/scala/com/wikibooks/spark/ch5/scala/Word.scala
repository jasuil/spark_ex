package com.wikibooks.spark.ch5.scala

case class Word(word: String, count: Int)