package com.scalademo.basic

object Ex01BasicSyntax {
  
  def main(args: Array[String]) = {
    
    println("Hello, Scala Programming World !!!!!")
    println("This is my first scala program")
    println("Bye")
    
  }
  
}