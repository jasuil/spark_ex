package com.scalademo.basic

object Ex03Operators {
  def main(args: Array[String]): Unit = {
    
      println("Check later !!!!!")
      
      
    
  }
}